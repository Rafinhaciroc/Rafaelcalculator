﻿/*
Copyright (c) 2003-2012, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/

CKEDITOR.plugins.setLang('placeholder','ug',{placeholder:{title:'ئورۇن بەلگە خاسلىقى',toolbar:'ئورۇن بەلگە قۇر',text:'ئورۇن بەلگە تېكىستى',edit:'ئورۇن بەلگە تەھرىر',textMissing:'ئورۇن بەلگىسىدە چوقۇم تېكىست بولۇشى لازىم'}});
